#!/usr/bin/env python3
"""
COMPLETE REAL LEAD GENERATION SYSTEM
Combines GitHub scraping + Enrichment + GHL Export
NO FAKE DATA - ONLY REAL LEADS
"""

import sys
import time
from datetime import datetime

sys.path.append('/app')
sys.path.append('/app/controllers')

def find_real_marketing_agencies():
    """
    Find REAL marketing agencies from GitHub and enrich them
    """
    
    print("=" * 60)
    print("SPECTRUM REAL LEAD FINDER")
    print("=" * 60)
    
    # Import controllers
    from real_lead_scraper import RealLeadScraper
    from lead_enrichment_pipeline import LeadEnrichmentPipeline
    from email_pattern_controller import EmailPatternController
    
    # Initialize
    scraper = RealLeadScraper()
    enricher = LeadEnrichmentPipeline()
    
    # Step 1: Find REAL agencies on GitHub
    print("\n[STEP 1] Finding Real Marketing Agencies on GitHub...")
    
    search_queries = [
        "marketing agency CEO founder",
        "digital marketing owner",
        "growth hacking founder",
        "performance marketing CEO",
        "GoHighLevel expert"
    ]
    
    all_leads = []
    
    for query in search_queries[:2]:  # Limit to preserve rate limit
        print(f"\n🔍 Searching: {query}")
        leads = scraper.scrape_github_users(query, location="United States")
        all_leads.extend(leads)
        time.sleep(2)  # Respect rate limits
    
    print(f"\n✅ Found {len(all_leads)} total leads from GitHub")
    
    # Step 2: Filter for relevant leads
    print("\n[STEP 2] Filtering for Relevant Leads...")
    
    relevant_leads = []
    for lead in all_leads:
        # Check if they mention marketing/agency in bio or company
        bio = (lead.get('bio', '') or '').lower()
        company = (lead.get('company', '') or '').lower()
        
        relevant_keywords = ['marketing', 'agency', 'digital', 'growth', 'seo', 'ppc', 'social media']
        
        if any(keyword in bio + company for keyword in relevant_keywords):
            relevant_leads.append(lead)
            print(f"  ✅ Relevant: {lead.get('name', 'Unknown')} - {lead.get('company', 'No company')}")
    
    print(f"\n📊 {len(relevant_leads)} relevant leads identified")
    
    # Step 3: Enrich all relevant leads
    print("\n[STEP 3] Enriching Leads...")
    
    enriched_leads = enricher.bulk_enrich(relevant_leads[:5])  # Top 5 for demo
    
    # Step 4: Display results
    print("\n" + "=" * 60)
    print("TOP QUALIFIED LEADS (REAL DATA)")
    print("=" * 60)
    
    for i, lead in enumerate(enriched_leads[:3], 1):
        print(f"\n🏆 LEAD {i} - Score: {lead.get('lead_score', 0)}/100")
        print("-" * 40)
        print(f"Name: {lead.get('name', 'Unknown')}")
        print(f"Company: {lead.get('company', 'Unknown')}")
        print(f"Email: {lead.get('email') or lead.get('primary_email_guess', 'Need to verify')}")
        print(f"Website: {lead.get('blog', 'Unknown')}")
        print(f"GitHub: {lead.get('github_url', 'N/A')}")
        print(f"Tech Stack: {', '.join(lead.get('tech_stack', ['Unknown']))}")
        print(f"Company Size: {lead.get('company_size_estimate', 'Unknown')}")
        print(f"Outreach: {lead.get('outreach_strategy', {}).get('message_angle', 'Generic')}")
    
    # Step 5: Export readiness
    print("\n" + "=" * 60)
    print("EXPORT READY")
    print("=" * 60)
    
    print(f"\n✅ {len(enriched_leads)} leads ready for GHL export")
    print("📧 Email variations generated for all leads")
    print("🔧 Tech stacks detected where possible")
    print("📊 All leads scored and prioritized")
    
    print("\n🚀 Next Step: Connect GHL and run:")
    print('  orchestrator.export_to_ghl(enriched_leads, min_score=50)')
    
    return enriched_leads


if __name__ == "__main__":
    # Run the complete pipeline
    real_leads = find_real_marketing_agencies()
    
    # Save to file
    import json
    with open('/app/real_marketing_leads.json', 'w') as f:
        # Convert to JSON-serializable format
        clean_leads = []
        for lead in real_leads:
            clean_lead = {k: v for k, v in lead.items() if v is not None}
            clean_leads.append(clean_lead)
        
        json.dump(clean_leads, f, indent=2, default=str)
    
    print("\n💾 Saved to /app/real_marketing_leads.json")
