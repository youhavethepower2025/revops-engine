#!/usr/bin/env python3
"""
Lead Enrichment Pipeline
Takes basic lead info and enriches it with everything we can find
"""

import re
import requests
from typing import Dict, List, Optional
from datetime import datetime
import hashlib

class LeadEnrichmentPipeline:
    """
    Takes a basic lead and enriches it with:
    - Email patterns
    - Tech stack
    - Social profiles
    - Company info
    - Contact methods
    """
    
    def __init__(self, brain=None, email_controller=None):
        self.brain = brain
        self.email_controller = email_controller
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
        })
    
    def enrich_lead(self, lead: Dict) -> Dict:
        """
        Master enrichment function
        Takes basic lead and adds everything we can find
        """
        print(f"\n🔧 Enriching: {lead.get('name', 'Unknown')} @ {lead.get('company', 'Unknown')}")
        
        enriched = lead.copy()
        enriched['enrichment_started'] = datetime.now().isoformat()
        
        # Step 1: Generate email if not present
        if not enriched.get('email'):
            enriched = self.generate_email_addresses(enriched)
        
        # Step 2: Extract domain from website/blog
        if enriched.get('blog') or enriched.get('website'):
            enriched['domain'] = self.extract_domain(enriched.get('blog') or enriched.get('website'))
        
        # Step 3: Detect company tech stack
        if enriched.get('domain'):
            enriched['tech_stack'] = self.detect_tech_stack(enriched['domain'])
        
        # Step 4: Find social profiles
        enriched = self.find_social_profiles(enriched)
        
        # Step 5: Estimate company size
        enriched['company_size_estimate'] = self.estimate_company_size(enriched)
        
        # Step 6: Calculate lead score
        enriched['lead_score'] = self.calculate_lead_score(enriched)
        
        # Step 7: Determine outreach strategy
        enriched['outreach_strategy'] = self.suggest_outreach_strategy(enriched)
        
        # Step 8: Cache the enriched lead
        if self.brain:
            self.cache_enriched_lead(enriched)
        
        enriched['enrichment_completed'] = datetime.now().isoformat()
        
        print(f"  ✅ Enrichment complete - Score: {enriched['lead_score']}/100")
        
        return enriched
    
    def generate_email_addresses(self, lead: Dict) -> Dict:
        """Generate likely email addresses"""
        
        # Parse name
        name_parts = (lead.get('name', '') or '').split()
        if len(name_parts) >= 2:
            first_name = name_parts[0]
            last_name = name_parts[-1]
        else:
            first_name = name_parts[0] if name_parts else ''
            last_name = ''
        
        # Get domain from company website or guess it
        domain = lead.get('domain')
        if not domain and lead.get('company'):
            # Clean company name and guess domain
            company_clean = re.sub(r'[@\s\-_]+', '', lead['company'].lower())
            domain = f"{company_clean}.com"
        
        if first_name and domain:
            # Generate variations
            email_variations = []
            
            patterns = [
                f"{first_name.lower()}@{domain}",
                f"{first_name.lower()}.{last_name.lower()}@{domain}" if last_name else None,
                f"{first_name[0].lower()}{last_name.lower()}@{domain}" if last_name else None,
                f"{first_name.lower()}{last_name[0].lower()}@{domain}" if last_name else None,
            ]
            
            for pattern in patterns:
                if pattern:
                    email_variations.append(pattern)
            
            lead['email_variations'] = email_variations
            lead['primary_email_guess'] = email_variations[0] if email_variations else None
            
            print(f"  📧 Generated {len(email_variations)} email variations")
        
        return lead
    
    def extract_domain(self, url: str) -> str:
        """Extract clean domain from URL"""
        if not url:
            return None
        
        # Add protocol if missing
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        
        try:
            from urllib.parse import urlparse
            parsed = urlparse(url)
            domain = parsed.netloc.lower()
            
            # Remove www.
            if domain.startswith('www.'):
                domain = domain[4:]
            
            return domain
        except:
            return None
    
    def detect_tech_stack(self, domain: str) -> List[str]:
        """Detect technologies used by checking response headers and common paths"""
        
        tech_stack = []
        
        if not domain:
            return tech_stack
        
        try:
            # Check main site
            response = self.session.get(f'https://{domain}', timeout=5)
            headers = response.headers
            content = response.text[:50000]  # First 50KB
            
            # Check headers for technology clues
            if 'x-powered-by' in headers:
                tech_stack.append(headers['x-powered-by'])
            
            # Check for common technologies in content
            tech_patterns = {
                'WordPress': ['wp-content', 'wp-includes', 'wordpress'],
                'Shopify': ['shopify', 'myshopify.com', 'cdn.shopify'],
                'GoHighLevel': ['gohighlevel', 'ghl', 'msgsndr'],
                'ClickFunnels': ['clickfunnels', 'cfnew.com'],
                'Webflow': ['webflow.com', 'webflow.io'],
                'Wix': ['wix.com', 'wixsite.com'],
                'Squarespace': ['squarespace.com', 'sqsp.net'],
                'HubSpot': ['hubspot', 'hs-scripts', 'hsforms'],
                'Google Analytics': ['google-analytics.com', 'gtag', 'ga.js'],
                'Facebook Pixel': ['facebook.com/tr', 'fbq('],
                'Intercom': ['intercom.io', 'intercomcdn'],
                'Drift': ['drift.com', 'driftt'],
                'Klaviyo': ['klaviyo.com'],
                'Mailchimp': ['mailchimp.com', 'chimpstatic.com'],
            }
            
            for tech, patterns in tech_patterns.items():
                if any(pattern in content.lower() for pattern in patterns):
                    tech_stack.append(tech)
            
            print(f"  🔧 Detected {len(tech_stack)} technologies")
            
        except Exception as e:
            print(f"  ⚠️ Could not detect tech stack: {e}")
        
        return tech_stack
    
    def find_social_profiles(self, lead: Dict) -> Dict:
        """Find social media profiles"""
        
        # If we have Twitter username, build URL
        if lead.get('twitter'):
            lead['twitter_url'] = f"https://twitter.com/{lead['twitter']}"
        
        # LinkedIn search URL (for manual lookup)
        if lead.get('name'):
            lead['linkedin_search'] = f"https://www.linkedin.com/search/results/people/?keywords={lead['name'].replace(' ', '%20')}"
        
        # GitHub is already provided
        if lead.get('github_url'):
            lead['github_username'] = lead['github_url'].split('/')[-1]
        
        return lead
    
    def estimate_company_size(self, lead: Dict) -> str:
        """Estimate company size based on available signals"""
        
        # Signals for size estimation
        signals = []
        
        # GitHub followers can indicate influence
        if lead.get('followers', 0) > 100:
            signals.append('large')
        elif lead.get('followers', 0) > 20:
            signals.append('medium')
        else:
            signals.append('small')
        
        # Tech stack complexity
        tech_count = len(lead.get('tech_stack', []))
        if tech_count > 5:
            signals.append('large')
        elif tech_count > 2:
            signals.append('medium')
        else:
            signals.append('small')
        
        # Company name patterns
        company = (lead.get('company', '') or '').lower()
        if any(word in company for word in ['agency', 'group', 'solutions']):
            signals.append('medium')
        elif any(word in company for word in ['freelance', 'consulting']):
            signals.append('small')
        elif any(word in company for word in ['inc', 'corp', 'ltd']):
            signals.append('large')
        
        # Determine size based on signals
        if signals.count('large') >= 2:
            return '50+ employees'
        elif signals.count('medium') >= 2:
            return '10-50 employees'
        else:
            return '1-10 employees'
    
    def calculate_lead_score(self, lead: Dict) -> int:
        """Calculate lead quality score 0-100"""
        
        score = 0
        
        # Has email or email guess: +20
        if lead.get('email') or lead.get('primary_email_guess'):
            score += 20
        
        # Has company: +15
        if lead.get('company'):
            score += 15
        
        # Has website: +15
        if lead.get('domain'):
            score += 15
        
        # Uses competitor tools: +20
        competitor_tools = ['gohighlevel', 'clickfunnels', 'hubspot']
        if any(tool in lead.get('tech_stack', []) for tool in competitor_tools):
            score += 20
        
        # Has multiple contact methods: +10
        contact_methods = sum([
            bool(lead.get('email')),
            bool(lead.get('twitter')),
            bool(lead.get('github_url')),
            bool(lead.get('blog'))
        ])
        if contact_methods >= 2:
            score += 10
        
        # Active on GitHub: +10
        if lead.get('followers', 0) > 10:
            score += 10
        
        # Decision maker title: +10
        title_keywords = ['ceo', 'founder', 'owner', 'president', 'director']
        bio = (lead.get('bio', '') or '').lower()
        if any(keyword in bio for keyword in title_keywords):
            score += 10
        
        return min(score, 100)
    
    def suggest_outreach_strategy(self, lead: Dict) -> Dict:
        """Suggest best way to reach this lead"""
        
        strategy = {
            'priority': 'medium',
            'channels': [],
            'message_angle': '',
            'best_time': ''
        }
        
        # Determine priority
        if lead.get('lead_score', 0) >= 70:
            strategy['priority'] = 'high'
        elif lead.get('lead_score', 0) >= 40:
            strategy['priority'] = 'medium'
        else:
            strategy['priority'] = 'low'
        
        # Determine channels
        if lead.get('email') or lead.get('primary_email_guess'):
            strategy['channels'].append('email')
        
        if lead.get('twitter'):
            strategy['channels'].append('twitter')
        
        if lead.get('github_url'):
            strategy['channels'].append('github')
        
        # Determine message angle
        if 'gohighlevel' in lead.get('tech_stack', []):
            strategy['message_angle'] = 'Better GHL automation - 10x faster management'
        elif 'agency' in (lead.get('company', '') or '').lower():
            strategy['message_angle'] = 'Agency automation - manage all clients in one conversation'
        else:
            strategy['message_angle'] = 'Stop clicking through 50 tools - use one conversation'
        
        # Best time (based on timezone if available)
        strategy['best_time'] = 'Tue-Thu 10am-12pm their timezone'
        
        return strategy
    
    def cache_enriched_lead(self, lead: Dict) -> bool:
        """Cache enriched lead in brain's L2 memory"""
        
        if not self.brain:
            return False
        
        # Create unique cache key
        cache_parts = [
            lead.get('name', ''),
            lead.get('company', ''),
            lead.get('email', '')
        ]
        
        cache_string = '_'.join(filter(None, cache_parts))
        if cache_string:
            cache_key = f"enriched_{hashlib.md5(cache_string.encode()).hexdigest()[:8]}"
            
            # Store in L2 with timestamp
            lead['cache_key'] = cache_key
            lead['cached_at'] = datetime.now().isoformat()
            
            self.brain.remember_l2(cache_key, lead)
            
            print(f"  💾 Cached as: {cache_key}")
            return True
        
        return False
    
    def bulk_enrich(self, leads: List[Dict]) -> List[Dict]:
        """Enrich multiple leads at once"""
        
        enriched_leads = []
        
        print(f"\n🚀 Enriching {len(leads)} leads...")
        
        for i, lead in enumerate(leads, 1):
            print(f"\n[{i}/{len(leads)}]", end='')
            enriched = self.enrich_lead(lead)
            enriched_leads.append(enriched)
        
        # Sort by score
        enriched_leads.sort(key=lambda x: x.get('lead_score', 0), reverse=True)
        
        print(f"\n\n✅ Enrichment complete!")
        print(f"📊 Score distribution:")
        print(f"  High (70+): {sum(1 for l in enriched_leads if l.get('lead_score', 0) >= 70)}")
        print(f"  Medium (40-69): {sum(1 for l in enriched_leads if 40 <= l.get('lead_score', 0) < 70)}")
        print(f"  Low (<40): {sum(1 for l in enriched_leads if l.get('lead_score', 0) < 40)}")
        
        return enriched_leads


if __name__ == "__main__":
    # Test with a real lead
    test_lead = {
        'name': 'Richard Gibbons',
        'company': 'Digital Applied',
        'blog': 'https://www.digitalapplied.com/',
        'github_url': 'https://github.com/digitalapplied',
        'followers': 8,
        'bio': 'Founder/CEO of Digital Applied - Digital Marketing Agency'
    }
    
    pipeline = LeadEnrichmentPipeline()
    enriched = pipeline.enrich_lead(test_lead)
    
    print("\n📋 Enriched Lead:")
    print(f"  Name: {enriched.get('name')}")
    print(f"  Email Guess: {enriched.get('primary_email_guess')}")
    print(f"  Tech Stack: {', '.join(enriched.get('tech_stack', []))}")
    print(f"  Company Size: {enriched.get('company_size_estimate')}")
    print(f"  Lead Score: {enriched.get('lead_score')}/100")
    print(f"  Strategy: {enriched.get('outreach_strategy', {}).get('message_angle')}")
