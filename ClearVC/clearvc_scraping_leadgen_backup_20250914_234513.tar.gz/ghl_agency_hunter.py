#!/usr/bin/env python3
"""
GHL AGENCY HUNTER - Find and dominate GHL agencies
They're all hungry, competing, desperate for an edge
We give them superpowers through their client's eyes
"""

import requests
import json
import time
from typing import Dict, List
from datetime import datetime

class GHLAgencyHunter:
    """
    Specifically targets GoHighLevel agencies
    These people are HUNGRY and need what we have
    """
    
    def __init__(self):
        self.hunter_api_key = "7768bb0d256dad3786e42a5c7c5160693755838f"
        self.session = requests.Session()
        self.ghl_agency_domains = []
        self.qualified_agencies = []
        
    def find_ghl_agencies_google(self) -> List[str]:
        """
        Find GHL agencies through Google dorking
        Returns list of domains to enrich with Hunter
        """
        print("\n🎯 HUNTING GHL AGENCIES")
        print("=" * 60)
        
        # These searches would find REAL GHL agencies
        search_patterns = [
            '"powered by gohighlevel"',
            '"gohighlevel expert" agency',
            '"ghl specialist" "book a call"',
            '"white label gohighlevel"',
            'site:gohighlevel.com/users',
            '"gohighlevel partner" contact',
            '"we use gohighlevel" testimonial',
            '"built on gohighlevel" agency'
        ]
        
        domains = [
            # Known GHL agencies (for demonstration)
            "leadsnap.com",
            "automateandscale.com", 
            "gohighlevel.com",
            "clickfunnels.com",  # They compete with GHL
            "kajabi.com"  # Also compete
        ]
        
        print(f"  📍 Found {len(domains)} potential GHL agency domains")
        
        return domains
    
    def enrich_agency_with_hunter(self, domain: str) -> Dict:
        """
        Use Hunter.io to get EVERYTHING about an agency
        """
        print(f"\n🔍 Enriching: {domain}")
        
        agency_data = {
            'domain': domain,
            'emails': [],
            'company_info': {},
            'pattern': None,
            'technologies': [],
            'decision_makers': []
        }
        
        # 1. Domain Search - Find all emails at company
        try:
            response = requests.get(
                'https://api.hunter.io/v2/domain-search',
                params={
                    'domain': domain,
                    'api_key': self.hunter_api_key
                }
            )
            
            if response.status_code == 200:
                data = response.json()
                
                # Extract company info
                agency_data['company_info'] = {
                    'name': data['data'].get('organization'),
                    'description': data['data'].get('description'),
                    'industry': data['data'].get('industry'),
                    'size': data['data'].get('size'),
                    'location': data['data'].get('country'),
                    'social': {
                        'linkedin': data['data'].get('linkedin'),
                        'twitter': data['data'].get('twitter'),
                        'facebook': data['data'].get('facebook')
                    }
                }
                
                # Extract email pattern
                agency_data['pattern'] = data['data'].get('pattern')
                print(f"  📧 Email pattern: {agency_data['pattern']}")
                
                # Extract all emails found
                for email_data in data['data'].get('emails', []):
                    email_info = {
                        'email': email_data.get('value'),
                        'first_name': email_data.get('first_name'),
                        'last_name': email_data.get('last_name'),
                        'position': email_data.get('position'),
                        'department': email_data.get('department'),
                        'confidence': email_data.get('confidence'),
                        'type': email_data.get('type')  # personal or generic
                    }
                    
                    # Flag decision makers
                    position = (email_data.get('position') or '').lower()
                    if any(title in position for title in ['ceo', 'founder', 'owner', 'president', 'director', 'head']):
                        email_info['is_decision_maker'] = True
                        agency_data['decision_makers'].append(email_info)
                    
                    agency_data['emails'].append(email_info)
                
                print(f"  ✅ Found {len(agency_data['emails'])} emails")
                print(f"  👔 Found {len(agency_data['decision_makers'])} decision makers")
                
        except Exception as e:
            print(f"  ❌ Hunter error: {e}")
        
        # 2. Company Enrichment
        try:
            response = requests.get(
                'https://api.hunter.io/v2/companies/find',
                params={
                    'domain': domain,
                    'api_key': self.hunter_api_key
                }
            )
            
            if response.status_code == 200:
                data = response.json()
                company = data.get('data', {})
                
                # Add extra company details
                agency_data['company_info'].update({
                    'founded': company.get('founded'),
                    'employees': company.get('size'),
                    'revenue': company.get('revenue'),
                    'technologies': company.get('technologies', [])
                })
                
                agency_data['technologies'] = company.get('technologies', [])
                
                # Check if they use GHL or competitors
                tech_stack = ' '.join(agency_data['technologies']).lower()
                if any(tool in tech_stack for tool in ['gohighlevel', 'ghl', 'clickfunnels', 'kajabi', 'kartra']):
                    agency_data['uses_marketing_automation'] = True
                    print(f"  🎯 USES MARKETING AUTOMATION!")
                
        except Exception as e:
            print(f"  ⚠️ Company enrichment failed: {e}")
        
        # Calculate agency score
        agency_data['score'] = self.score_agency(agency_data)
        
        return agency_data
    
    def score_agency(self, agency: Dict) -> int:
        """
        Score agency based on how good a fit they are
        """
        score = 0
        
        # Has decision maker emails: +30
        if agency.get('decision_makers'):
            score += 30
        
        # Has email pattern: +20
        if agency.get('pattern'):
            score += 20
        
        # Multiple emails found: +15
        if len(agency.get('emails', [])) > 3:
            score += 15
        
        # Uses marketing automation: +25
        if agency.get('uses_marketing_automation'):
            score += 25
        
        # Has social profiles: +10
        if agency.get('company_info', {}).get('social', {}).get('linkedin'):
            score += 10
        
        return min(score, 100)
    
    def find_specific_person(self, domain: str, first_name: str, last_name: str) -> Dict:
        """
        Find specific person's email at agency
        """
        print(f"\n🎯 Finding: {first_name} {last_name} @ {domain}")
        
        response = requests.get(
            'https://api.hunter.io/v2/email-finder',
            params={
                'domain': domain,
                'first_name': first_name,
                'last_name': last_name,
                'api_key': self.hunter_api_key
            }
        )
        
        if response.status_code == 200:
            data = response.json()
            email = data['data'].get('email')
            confidence = data['data'].get('score')
            
            print(f"  ✅ Found: {email} (confidence: {confidence}%)")
            
            # Verify the email
            return self.verify_email(email)
        
        return {}
    
    def verify_email(self, email: str) -> Dict:
        """
        Verify if email is deliverable
        """
        print(f"  🔍 Verifying: {email}")
        
        response = requests.get(
            'https://api.hunter.io/v2/email-verifier',
            params={
                'email': email,
                'api_key': self.hunter_api_key
            }
        )
        
        if response.status_code == 200:
            data = response.json()
            result = data['data'].get('result')  # valid, invalid, risky, unknown
            score = data['data'].get('score')
            
            print(f"    Status: {result} (score: {score})")
            
            return {
                'email': email,
                'deliverable': result in ['valid', 'risky'],
                'status': result,
                'score': score
            }
        
        return {'email': email, 'deliverable': False}
    
    def enrich_person(self, email: str) -> Dict:
        """
        Get full details about a person from their email
        """
        print(f"\n👤 Enriching person: {email}")
        
        response = requests.get(
            'https://api.hunter.io/v2/people/find',
            params={
                'email': email,
                'api_key': self.hunter_api_key
            }
        )
        
        if response.status_code == 200:
            data = response.json()
            person = data.get('data', {})
            
            return {
                'email': email,
                'name': person.get('name'),
                'position': person.get('position'),
                'company': person.get('company'),
                'linkedin': person.get('linkedin'),
                'twitter': person.get('twitter'),
                'phone': person.get('phone')
            }
        
        return {}
    
    def hunt_ghl_agencies(self, limit: int = 5) -> List[Dict]:
        """
        Complete hunting pipeline for GHL agencies
        """
        print("\n" + "=" * 60)
        print("🎯 GHL AGENCY HUNTING MISSION")
        print("=" * 60)
        
        # Step 1: Find GHL agency domains
        domains = self.find_ghl_agencies_google()
        
        # Step 2: Enrich each agency
        agencies = []
        for domain in domains[:limit]:
            agency = self.enrich_agency_with_hunter(domain)
            agencies.append(agency)
            time.sleep(1)  # Be nice to Hunter API
        
        # Step 3: Sort by score
        agencies.sort(key=lambda x: x.get('score', 0), reverse=True)
        
        # Step 4: Display results
        print("\n" + "=" * 60)
        print("🏆 TOP GHL AGENCIES TO TARGET")
        print("=" * 60)
        
        for i, agency in enumerate(agencies[:3], 1):
            print(f"\n#{i} {agency['domain']} - Score: {agency['score']}/100")
            print(f"  Company: {agency['company_info'].get('name', 'Unknown')}")
            print(f"  Pattern: {agency.get('pattern', 'Unknown')}")
            print(f"  Emails Found: {len(agency.get('emails', []))}")
            
            # Show decision makers
            if agency.get('decision_makers'):
                print(f"  Decision Makers:")
                for dm in agency['decision_makers'][:2]:
                    print(f"    - {dm['first_name']} {dm['last_name']} ({dm['position']})")
                    print(f"      Email: {dm['email']} (confidence: {dm['confidence']}%)")
        
        # Save results
        with open('/app/ghl_agencies_hunted.json', 'w') as f:
            json.dump(agencies, f, indent=2, default=str)
        
        print(f"\n💾 Saved {len(agencies)} agencies to /app/ghl_agencies_hunted.json")
        
        return agencies
    
    def create_outreach_strategy(self, agency: Dict) -> Dict:
        """
        Create specific outreach strategy for GHL agency
        """
        strategy = {
            'subject_lines': [],
            'opening_lines': [],
            'value_props': [],
            'cta': ''
        }
        
        # Subject lines that work for GHL agencies
        strategy['subject_lines'] = [
            "Make your GHL clients think you're a wizard",
            "Stop clicking through GHL for hours",
            "Your clients won't believe what you built",
            "10x your GHL efficiency (not clickbait)"
        ]
        
        # Opening lines based on their pain
        strategy['opening_lines'] = [
            f"I know you're managing {len(agency.get('emails', []))} team members in GHL...",
            "How many hours did you spend in GHL yesterday?",
            "Your clients think you're manually doing everything. Good.",
            "What if you could manage all your GHL clients with just conversation?"
        ]
        
        # Value props
        strategy['value_props'] = [
            "Manage all your GHL accounts through natural conversation",
            "Your clients think you have a team of 50. It's just you and Spectrum.",
            "Stop training VAs on GHL. Talk to Spectrum instead.",
            "Be in 10 client accounts at once without 10 browser tabs"
        ]
        
        # CTA
        strategy['cta'] = "Want to see me manage your GHL in real-time? 15 min demo, no BS."
        
        return strategy


if __name__ == "__main__":
    # Run the GHL agency hunter
    hunter = GHLAgencyHunter()
    agencies = hunter.hunt_ghl_agencies(limit=3)
    
    print("\n" + "=" * 60)
    print("💡 OUTREACH STRATEGY")
    print("=" * 60)
    
    if agencies:
        top_agency = agencies[0]
        strategy = hunter.create_outreach_strategy(top_agency)
        
        print(f"\nFor {top_agency['domain']}:")
        print(f"\n📧 Subject: {strategy['subject_lines'][0]}")
        print(f"👋 Opening: {strategy['opening_lines'][0]}")
        print(f"💰 Value: {strategy['value_props'][0]}")
        print(f"🎯 CTA: {strategy['cta']}")
    
    print("\n🚀 Ready to destroy the GHL agency market!")
