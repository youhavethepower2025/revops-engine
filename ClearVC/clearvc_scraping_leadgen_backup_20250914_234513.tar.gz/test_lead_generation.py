#!/usr/bin/env python3
"""
Lead Generation Pipeline Test
Connects all Day 1 controllers and runs a test to find GHL agencies
"""

import sys
import json
from datetime import datetime

# Import all controllers
sys.path.append('/app')
sys.path.append('/app/controllers')

from lead_orchestrator_controller import LeadOrchestratorController
from google_dork_controller import GoogleDorkController
from email_pattern_controller import EmailPatternController
from ghl_controller import GHLController

def test_lead_generation_pipeline():
    """
    Test the complete lead generation pipeline
    Find agencies using GoHighLevel and generate their contact info
    """
    
    print("=" * 60)
    print("SPECTRUM LEAD GENERATION PIPELINE TEST")
    print("=" * 60)
    
    # Initialize controllers
    print("\n[1/5] Initializing Controllers...")
    orchestrator = LeadOrchestratorController()
    google_dork = GoogleDorkController()
    email_pattern = EmailPatternController()
    
    print("✅ Lead Orchestrator Controller: READY")
    print("✅ Google Dork Controller: READY")
    print("✅ Email Pattern Controller: READY")
    
    # Test 1: Find GHL Agencies using Google Dorks
    print("\n[2/5] Finding GoHighLevel Agencies...")
    print("Query: Agencies using GoHighLevel with testimonials")
    
    ghl_agencies = google_dork.find_by_technology(
        technology='gohighlevel',
        industry='agency'
    )
    
    print(f"✅ Found {len(ghl_agencies)} potential agencies")
    
    # Show first 3 results
    for i, agency in enumerate(ghl_agencies[:3], 1):
        print(f"\n  Agency {i}:")
        print(f"    Company: {agency.get('company_name', 'Unknown')}")
        print(f"    Website: {agency.get('website', 'N/A')}")
        print(f"    Technology: {agency.get('technology_detected', 'N/A')}")
    
    # Test 2: Find testimonials from competitors
    print("\n[3/5] Finding Competitor Testimonials...")
    
    testimonials = google_dork.find_testimonials(
        competitor='gohighlevel',
        industry='marketing'
    )
    
    print(f"✅ Found {len(testimonials)} testimonials mentioning GoHighLevel")
    
    for i, testimonial in enumerate(testimonials[:2], 1):
        print(f"\n  Testimonial {i}:")
        print(f"    Source: {testimonial.get('website', 'Unknown')}")
        print(f"    Has Testimonials: {testimonial.get('has_testimonials', False)}")
    
    # Test 3: Generate emails for found leads
    print("\n[4/5] Generating Email Addresses...")
    
    # Create test people from agencies
    test_people = [
        {'first_name': 'John', 'last_name': 'Smith', 'company': 'Marketing Pro Agency'},
        {'first_name': 'Sarah', 'last_name': 'Johnson', 'company': 'Digital Growth Co'},
        {'first_name': 'Mike', 'last_name': 'Williams', 'company': 'Agency Masters'},
    ]
    
    for person in test_people:
        result = email_pattern.generate_email(
            first_name=person['first_name'],
            last_name=person['last_name'],
            company=person['company']
        )
        
        print(f"\n  {person['first_name']} {person['last_name']} @ {person['company']}:")
        print(f"    Generated Email: {result.get('email', 'Failed')}")
        print(f"    Confidence: {result.get('confidence', 0):.1%}")
        print(f"    Pattern Used: {result.get('pattern_used', 'N/A')}")
    
    # Test 4: Full orchestration
    print("\n[5/5] Running Full Lead Orchestration...")
    
    criteria = {
        'keywords': ['marketing agency', 'digital agency'],
        'technologies': ['gohighlevel', 'clickfunnels'],
        'location': 'USA'
    }
    
    orchestrated_leads = orchestrator.find_leads(criteria)
    
    print(f"✅ Orchestrator found and enriched {len(orchestrated_leads)} leads")
    
    # Show top 3 scored leads
    print("\n📊 Top Scored Leads:")
    for i, lead in enumerate(orchestrated_leads[:3], 1):
        print(f"\n  Lead {i} (Score: {lead.get('score', 0)}/100):")
        print(f"    Company: {lead.get('company_name', 'Unknown')}")
        print(f"    Email: {lead.get('email', 'Not generated')}")
        print(f"    Website: {lead.get('website', 'N/A')}")
        print(f"    Tech Stack: {', '.join(lead.get('tech_stack', []))}")
        print(f"    Revenue Est: {lead.get('revenue_estimate', 'Unknown')}")
    
    # Test 5: Pattern Detection
    print("\n[BONUS] Email Pattern Detection Test...")
    
    known_emails = [
        'john.smith@company.com',
        'sarah.johnson@company.com',
        'mike.williams@company.com'
    ]
    
    detected_pattern = email_pattern.detect_pattern(known_emails)
    print(f"✅ Detected Pattern: {detected_pattern}")
    
    # Now generate new email with detected pattern
    if detected_pattern:
        new_email = email_pattern.generate_email(
            first_name='Jane',
            last_name='Doe',
            domain='company.com',
            known_pattern=detected_pattern
        )
        print(f"✅ Generated new email using pattern: {new_email.get('email')}")
        print(f"   Confidence: {new_email.get('confidence', 0):.1%}")
    
    # Summary
    print("\n" + "=" * 60)
    print("PIPELINE TEST COMPLETE")
    print("=" * 60)
    print("\n📈 Summary:")
    print(f"  • Agencies Found: {len(ghl_agencies)}")
    print(f"  • Testimonials Found: {len(testimonials)}")
    print(f"  • Emails Generated: {len(test_people)}")
    print(f"  • Leads Orchestrated: {len(orchestrated_leads)}")
    print(f"  • Pattern Detection: {'✅ Working' if detected_pattern else '❌ Failed'}")
    
    print("\n🚀 Next Steps:")
    print("  1. Connect to live GHL account for export")
    print("  2. Add real Google search scraping")
    print("  3. Integrate paid APIs when funded")
    print("  4. Deploy to production Spectrum")
    
    return {
        'success': True,
        'agencies_found': len(ghl_agencies),
        'emails_generated': len(test_people),
        'pattern_detected': detected_pattern
    }

if __name__ == "__main__":
    # Run the test
    result = test_lead_generation_pipeline()
    
    # Save results to file
    with open('/app/lead_gen_test_results.json', 'w') as f:
        json.dump(result, f, indent=2)
    
    print("\n✅ Results saved to /app/lead_gen_test_results.json")
