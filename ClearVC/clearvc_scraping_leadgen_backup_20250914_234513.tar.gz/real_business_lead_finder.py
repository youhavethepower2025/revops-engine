#!/usr/bin/env python3
"""
REAL LEAD FINDER - No bullshit, no founders, no trash
Finding ACTUAL mid-size and enterprise companies that NEED automation
"""

import requests
import json
import time
from typing import Dict, List

class RealBusinessLeadFinder:
    """
    Finds REAL businesses, not celebrity founders
    Focuses on companies that actually buy software
    """
    
    def __init__(self):
        self.apis = {
            'hunter': '7768bb0d256dad3786e42a5c7c5160693755838f',
            'pdl': '626cf80730cab9d3fe07c56662b80b1648a436f0bfb6e3f9b8a7df803964f47b'
        }
        
        # REAL company domains - mid-size businesses that need automation
        self.target_domains = [
            # Digital Marketing Agencies (10-50 employees)
            "webfx.com",  # Large digital agency
            "thriveagency.com",  # Growing agency
            "ignitevisibility.com",  # SEO/marketing agency
            "disruptiveadvertising.com",  # PPC agency
            "smartsites.com",  # Digital marketing
            "coalitiontechnologies.com",  # LA agency
            "seoprofy.com",  # International agency
            "singlegrain.com",  # Eric Siu's agency
            "growthmarketing.com",  # Growth focused
            "sculptagency.com",  # E-commerce agency
            
            # Business Services Companies (need CRM/automation)
            "bamboohr.com",  # HR software
            "gusto.com",  # Payroll/HR
            "justworks.com",  # HR/payroll
            "rippling.com",  # HR/IT
            "carta.com",  # Equity management
            "bill.com",  # AP/AR automation
            "expensify.com",  # Expense management
            "divvy.com",  # Expense/credit
            
            # E-commerce/Retail (need marketing automation)
            "mvmtwatches.com",  # Watch brand
            "bombas.com",  # Sock company
            "rothys.com",  # Shoe brand
            "allbirds.com",  # Sustainable shoes
            "untuckit.com",  # Clothing
            "brooklinen.com",  # Bedding
            "purple.com",  # Mattresses
            "casper.com",  # Sleep products
            
            # SaaS Companies (understand automation value)
            "lemlist.com",  # Sales automation
            "phantombuster.com",  # We have their API!
            "useproof.com",  # Social proof
            "demio.com",  # Webinar platform
            "convertflow.com",  # CRO platform
            "rightmessage.com",  # Personalization
            "videofruit.com",  # Content tools
            "sumo.com",  # Marketing tools
            
            # Real Estate/Property Management
            "rentberry.com",  # Rental platform
            "apartments247.com",  # Property management
            "buildium.com",  # Property software
            "appfolio.com",  # Property management
            
            # Healthcare/Wellness (huge market)
            "zocdoc.com",  # Doctor booking
            "practicefusion.com",  # EHR
            "simplybusiness.com",  # Insurance
            "gohealth.com",  # Insurance
            
            # Financial Services
            "lendingclub.com",  # Lending
            "fundera.com",  # Business loans
            "kabbage.com",  # Small business loans
            "ondeck.com",  # Business financing
            
            # Education/Training Companies
            "coursera.org",  # Online education
            "udacity.com",  # Tech training
            "pluralsight.com",  # Skills platform
            "datacamp.com",  # Data training
        ]
    
    def find_decision_makers(self, domain: str) -> List[Dict]:
        """
        Find REAL decision makers at REAL companies
        """
        print(f"\n🔍 Analyzing: {domain}")
        
        leads = []
        
        # Use Hunter to find people
        try:
            response = requests.get(
                'https://api.hunter.io/v2/domain-search',
                params={
                    'domain': domain,
                    'api_key': self.apis['hunter'],
                    'type': 'personal',  # Only personal emails
                    'seniority': 'senior,executive',  # Decision makers
                    'department': 'management,marketing,sales,it'  # Relevant departments
                }
            )
            
            if response.status_code == 200:
                data = response.json()['data']
                
                company_info = {
                    'domain': domain,
                    'company': data.get('organization', domain.split('.')[0].title()),
                    'description': data.get('description'),
                    'industry': data.get('industry'),
                    'size': data.get('size'),
                    'country': data.get('country'),
                    'pattern': data.get('pattern'),
                    'technologies': data.get('technologies', [])
                }
                
                print(f"  ✅ Company: {company_info['company']}")
                print(f"  📊 Size: {company_info.get('size', 'Unknown')}")
                print(f"  🏢 Industry: {company_info.get('industry', 'Unknown')}")
                
                # Process each person
                for person in data.get('emails', []):
                    # Filter for decision makers
                    position = (person.get('position') or '').lower()
                    department = (person.get('department') or '').lower()
                    
                    # We want C-level, VPs, Directors, Heads of departments
                    is_decision_maker = any([
                        'ceo' in position,
                        'cto' in position,
                        'cmo' in position,
                        'coo' in position,
                        'cfo' in position,
                        'founder' in position,
                        'president' in position,
                        'vp' in position,
                        'vice president' in position,
                        'director' in position,
                        'head of' in position,
                        'manager' in position and any(d in department for d in ['marketing', 'sales', 'growth'])
                    ])
                    
                    if is_decision_maker:
                        lead = {
                            'company_info': company_info,
                            'first_name': person.get('first_name'),
                            'last_name': person.get('last_name'),
                            'full_name': f"{person.get('first_name', '')} {person.get('last_name', '')}".strip(),
                            'email': person.get('value'),
                            'position': person.get('position'),
                            'department': person.get('department'),
                            'seniority': person.get('seniority'),
                            'confidence': person.get('confidence', 0),
                            'linkedin': person.get('linkedin'),
                            'twitter': person.get('twitter'),
                            'phone': person.get('phone_number'),
                            'sources': person.get('sources', 0)
                        }
                        
                        # Calculate lead quality score
                        score = 0
                        
                        # Email confidence
                        if lead['confidence'] > 95: score += 25
                        elif lead['confidence'] > 85: score += 20
                        elif lead['confidence'] > 75: score += 15
                        
                        # Position value
                        if 'ceo' in position or 'founder' in position: score += 30
                        elif 'vp' in position or 'vice president' in position: score += 25
                        elif 'director' in position: score += 20
                        elif 'head' in position: score += 15
                        elif 'manager' in position: score += 10
                        
                        # Department relevance
                        if 'marketing' in department: score += 15
                        elif 'sales' in department: score += 10
                        elif 'it' in department or 'technology' in department: score += 10
                        
                        # Company size (mid-size is ideal)
                        size = company_info.get('size', '')
                        if '51-200' in size or '201-500' in size: score += 20
                        elif '11-50' in size: score += 15
                        elif '501-1000' in size: score += 10
                        
                        # Has contact info
                        if lead.get('linkedin'): score += 5
                        if lead.get('phone'): score += 10
                        
                        lead['score'] = min(score, 100)
                        
                        # Only keep good leads
                        if score >= 40:
                            leads.append(lead)
                            print(f"    ✓ {lead['full_name']} - {lead['position']} (Score: {score})")
                
                if not leads:
                    print(f"  ⚠️ No decision makers found")
                            
        except Exception as e:
            print(f"  ❌ Error: {e}")
        
        return leads
    
    def find_real_leads(self, count: int = 20) -> List[Dict]:
        """
        Find REAL leads from REAL companies
        """
        print("\n" + "=" * 60)
        print("🎯 FINDING REAL BUSINESS LEADS")
        print("No founders, no tiny agencies, no bullshit")
        print("=" * 60)
        
        all_leads = []
        
        # Process companies until we have enough leads
        for domain in self.target_domains:
            if len(all_leads) >= count:
                break
                
            leads = self.find_decision_makers(domain)
            all_leads.extend(leads)
            
            # Rate limit
            time.sleep(1)
        
        # Sort by score
        all_leads.sort(key=lambda x: x['score'], reverse=True)
        
        # Take top leads
        top_leads = all_leads[:count]
        
        return top_leads
    
    def format_for_ghl(self, leads: List[Dict]) -> List[Dict]:
        """
        Format for GHL import
        """
        ghl_leads = []
        
        for lead in leads:
            company = lead['company_info']
            
            ghl_lead = {
                'firstName': lead.get('first_name', ''),
                'lastName': lead.get('last_name', ''),
                'email': lead.get('email', ''),
                'phone': lead.get('phone', ''),
                'companyName': company.get('company', ''),
                'website': f"https://{company.get('domain')}",
                'tags': [
                    'real-business',
                    f"score-{lead.get('score', 0)}",
                    f"size-{company.get('size', 'unknown')}",
                    company.get('industry', 'unknown').lower().replace(' ', '-'),
                    'spectrum-qualified'
                ],
                'customField': {
                    'position': lead.get('position', ''),
                    'department': lead.get('department', ''),
                    'company_size': company.get('size', ''),
                    'industry': company.get('industry', ''),
                    'lead_score': str(lead.get('score', 0)),
                    'email_confidence': str(lead.get('confidence', 0)),
                    'company_description': company.get('description', '')[:500] if company.get('description') else ''
                }
            }
            
            ghl_leads.append(ghl_lead)
        
        return ghl_leads


if __name__ == "__main__":
    # Find REAL leads
    finder = RealBusinessLeadFinder()
    real_leads = finder.find_real_leads(count=20)
    
    print("\n" + "=" * 60)
    print(f"🏆 TOP {len(real_leads)} REAL BUSINESS LEADS")
    print("=" * 60)
    
    # Group by company
    companies = {}
    for lead in real_leads:
        company_name = lead['company_info']['company']
        if company_name not in companies:
            companies[company_name] = []
        companies[company_name].append(lead)
    
    # Display results
    for company_name, company_leads in list(companies.items())[:10]:
        company_info = company_leads[0]['company_info']
        print(f"\n🏢 {company_name}")
        print(f"  Domain: {company_info['domain']}")
        print(f"  Size: {company_info.get('size', 'Unknown')}")
        print(f"  Industry: {company_info.get('industry', 'Unknown')}")
        
        print(f"  Decision Makers:")
        for lead in company_leads[:3]:  # Top 3 per company
            print(f"    • {lead['full_name']} - {lead['position']}")
            print(f"      Email: {lead['email']} ({lead['confidence']}% conf)")
            print(f"      Score: {lead['score']}/100")
    
    # Format for GHL
    ghl_formatted = finder.format_for_ghl(real_leads)
    
    # Save
    with open('/app/real_business_leads.json', 'w') as f:
        json.dump(ghl_formatted, f, indent=2, default=str)
    
    print(f"\n💾 Saved {len(ghl_formatted)} REAL leads to /app/real_business_leads.json")
    print("\n✅ These are REAL companies with REAL decision makers")
    print("✅ They have budget, they have needs, they're not celebrities")
    print("✅ Ready to import to GHL")
