#!/usr/bin/env python3
"""
Quick Vapi Bypass - Take control of your numbers through Twilio
No need to mess with Vapi's interface!
"""

import httpx
import asyncio
import json

TWILIO_ACCOUNT_SID = "ACd7564cf277675642888a72f63d1655a3"
TWILIO_AUTH_TOKEN = "e65397c32f16f83469ee9d859308eb6a"

async def check_number_status():
    """Check current webhook configuration for our numbers"""
    async with httpx.AsyncClient() as client:
        auth = (TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)

        # Check the main number
        response = await client.get(
            f"https://api.twilio.com/2010-04-01/Accounts/{TWILIO_ACCOUNT_SID}/IncomingPhoneNumbers.json",
            auth=auth,
            params={"PhoneNumber": "+13239685736"}
        )

        data = response.json()
        print(f"Response status: {response.status_code}")

        if 'incoming_phone_numbers' in data and data['incoming_phone_numbers']:
            number = data['incoming_phone_numbers'][0]
            print(f"📱 +13239685736 Status:")
            print(f"   SID: {number['sid']}")
            print(f"   Current Voice URL: {number.get('voice_url', 'None')}")
            print(f"   Voice Method: {number.get('voice_method', 'None')}")

            if 'vapi' in str(number.get('voice_url', '')).lower():
                print("   ⚠️  Currently controlled by Vapi")
                return number['sid'], True
            else:
                print("   ✅ Not controlled by Vapi")
                return number['sid'], False

        return None, False

async def bypass_vapi(number_sid: str):
    """Clear Vapi webhook - number becomes free"""
    async with httpx.AsyncClient() as client:
        auth = (TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)

        print(f"\n🔓 Releasing number from Vapi control...")

        # Clear the webhooks (makes number available)
        response = await client.post(
            f"https://api.twilio.com/2010-04-01/Accounts/{TWILIO_ACCOUNT_SID}/IncomingPhoneNumbers/{number_sid}.json",
            auth=auth,
            data={
                "VoiceUrl": "",  # Clear Vapi webhook
                "VoiceMethod": "POST",
                "SmsUrl": "",
                "SmsMethod": "POST",
                "StatusCallback": "",
                "StatusCallbackMethod": "POST"
            }
        )

        if response.status_code == 200:
            print("✅ Number released from Vapi!")
            print("   The number is now free to use with Retell")
            return True
        else:
            print(f"❌ Failed: {response.text}")
            return False

async def point_to_retell(number_sid: str):
    """Point number to Retell (we'll do this after configuring Retell)"""
    print("\n📞 To connect to Retell:")
    print("1. First run the Retell configuration")
    print("2. Then update webhook to: https://api.retellai.com/twilio-voice-webhook/<your_agent_id>")
    print("\nFor now, the number is FREE and ready!")

async def main():
    print("🚀 VAPI BYPASS TOOL")
    print("="*50)

    # Check current status
    number_sid, is_vapi = await check_number_status()

    if not number_sid:
        print("❌ Number not found in Twilio")
        return

    if is_vapi:
        print("\n⚡ Ready to take control!")
        input("Press Enter to bypass Vapi (Ctrl+C to cancel)...")

        if await bypass_vapi(number_sid):
            await point_to_retell(number_sid)
    else:
        print("\n✅ Number is already free from Vapi!")
        await point_to_retell(number_sid)

if __name__ == "__main__":
    asyncio.run(main())