#!/usr/bin/env python3
"""Clear Vapi webhooks from all Twilio numbers"""

import requests
from requests.auth import HTTPBasicAuth

# WORKING CREDS!
TWILIO_ACCOUNT_SID = "ACd7564cf277675642888a72f63d1655a3"
TWILIO_API_KEY = "SK451b658e7397ec5ad179ae1686ab5caf"
TWILIO_API_SECRET = "Z2lG0aDvABPaX7jE4eZ1xdvYU0tpQaOA"

auth = HTTPBasicAuth(TWILIO_API_KEY, TWILIO_API_SECRET)

print("🧹 CLEARING VAPI WEBHOOKS FROM TWILIO NUMBERS")
print("="*50)

# Get all numbers
numbers_url = f"https://api.twilio.com/2010-04-01/Accounts/{TWILIO_ACCOUNT_SID}/IncomingPhoneNumbers.json"
response = requests.get(numbers_url, auth=auth)

if response.status_code == 200:
    numbers = response.json()['incoming_phone_numbers']

    for number in numbers:
        phone = number['phone_number']
        sid = number['sid']
        current_webhook = number.get('voice_url', '')

        if 'vapi' in current_webhook.lower():
            print(f"\n📱 {phone}")
            print(f"   Current: {current_webhook}")
            print(f"   Clearing Vapi webhook...")

            # Clear the webhook
            update_url = f"https://api.twilio.com/2010-04-01/Accounts/{TWILIO_ACCOUNT_SID}/IncomingPhoneNumbers/{sid}.json"
            update_data = {
                'VoiceUrl': '',  # Clear it for now
                'VoiceMethod': 'POST',
                'StatusCallback': '',
                'StatusCallbackMethod': 'POST'
            }

            update_response = requests.post(update_url, auth=auth, data=update_data)

            if update_response.status_code == 200:
                print(f"   ✅ Cleared!")
            else:
                print(f"   ❌ Failed: {update_response.text}")
        else:
            print(f"\n📱 {phone} - No Vapi webhook found")

print("\n✅ VAPI WEBHOOKS CLEARED!")
print("Numbers are ready for Retell configuration")