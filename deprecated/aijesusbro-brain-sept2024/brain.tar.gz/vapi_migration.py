#!/usr/bin/env python3
"""
Vapi Number Migration Tool
Pull +13239685736 away from Vapi and bring it home to Retell
"""

import httpx
import asyncio
import json
from datetime import datetime

# Credentials
VAPI_API_KEY = "YOUR_VAPI_KEY"  # Need this from you if we're using API
TWILIO_ACCOUNT_SID = "ACd7564cf277675642888a72f63d1655a3"
TWILIO_AUTH_TOKEN = "e65397c32f16f83469ee9d859308eb6a"
RETELL_API_KEY = "key_819a6edef632ded41fe1c1ef7f12"

async def check_vapi_numbers():
    """Check what numbers Vapi currently has"""
    print("🔍 Checking Vapi numbers...")

    # If you have Vapi API access
    # async with httpx.AsyncClient() as client:
    #     response = await client.get(
    #         "https://api.vapi.ai/phone-numbers",
    #         headers={"Authorization": f"Bearer {VAPI_API_KEY}"}
    #     )
    #     numbers = response.json()
    #     print(f"Vapi has: {numbers}")

    print("Numbers currently with Vapi:")
    print("  - +13239685736 (primary)")
    print("  - +17255021112")

    return ["+13239685736", "+17255021112"]

async def release_from_vapi(number: str):
    """Release number from Vapi control"""
    print(f"🔓 Releasing {number} from Vapi...")

    # Option 1: Through Vapi API (if available)
    # async with httpx.AsyncClient() as client:
    #     response = await client.delete(
    #         f"https://api.vapi.ai/phone-numbers/{number}",
    #         headers={"Authorization": f"Bearer {VAPI_API_KEY}"}
    #     )

    # Option 2: Through Twilio directly (reconfigure routing)
    async with httpx.AsyncClient() as client:
        # Update Twilio number webhook to point away from Vapi
        auth = (TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)

        # Get the phone number SID
        response = await client.get(
            f"https://api.twilio.com/2010-04-01/Accounts/{TWILIO_ACCOUNT_SID}/IncomingPhoneNumbers.json",
            auth=auth,
            params={"PhoneNumber": number}
        )

        data = response.json()
        if data['incoming_phone_numbers']:
            number_sid = data['incoming_phone_numbers'][0]['sid']

            # Clear Vapi webhooks
            update_response = await client.post(
                f"https://api.twilio.com/2010-04-01/Accounts/{TWILIO_ACCOUNT_SID}/IncomingPhoneNumbers/{number_sid}.json",
                auth=auth,
                data={
                    "VoiceUrl": "",  # Clear Vapi webhook
                    "VoiceMethod": "POST",
                    "SmsUrl": "",
                    "SmsMethod": "POST"
                }
            )

            if update_response.status_code == 200:
                print(f"✅ Released {number} from Vapi")
                return True

    return False

async def configure_retell_sip():
    """Configure Retell with Twilio SIP trunk"""
    print("🔧 Configuring Retell SIP trunk...")

    async with httpx.AsyncClient() as client:
        # Create SIP trunk in Retell
        response = await client.post(
            "https://api.retellai.com/create-phone-number",
            headers={
                "Authorization": f"Bearer {RETELL_API_KEY}",
                "Content-Type": "application/json"
            },
            json={
                "provider": "twilio",
                "twilio_account_sid": TWILIO_ACCOUNT_SID,
                "twilio_auth_token": TWILIO_AUTH_TOKEN,
                "inbound_numbers": [
                    "+13239685736",  # Primary
                    "+17027109167",
                    "+17027186386",
                    "+17027104257",
                    "+17027124212",
                    "+17027104174",
                    "+18669658975"
                ]
            }
        )

        if response.status_code == 200:
            print("✅ Retell SIP trunk configured")
            return response.json()
        else:
            print(f"❌ Failed to configure Retell: {response.text}")
            return None

async def import_numbers_to_retell():
    """Import all Twilio numbers to Retell"""
    print("📞 Importing numbers to Retell...")

    numbers = [
        "+13239685736",  # Primary (from Vapi)
        "+17027109167",
        "+17027186386",
        "+17027104257",
        "+17027124212",
        "+17027104174",
        "+18669658975"
    ]

    async with httpx.AsyncClient() as client:
        for number in numbers:
            print(f"  Importing {number}...")

            # Register number with Retell
            response = await client.post(
                "https://api.retellai.com/register-phone-number",
                headers={
                    "Authorization": f"Bearer {RETELL_API_KEY}",
                    "Content-Type": "application/json"
                },
                json={
                    "phone_number": number,
                    "provider": "twilio",
                    "nickname": f"AI Jesus Bro - {number[-4:]}"
                }
            )

            if response.status_code == 200:
                print(f"  ✅ {number} imported")
            else:
                print(f"  ⚠️  {number} failed: {response.text}")

    print("✅ All numbers imported to Retell")

async def update_twilio_webhooks(brain_url: str):
    """Update Twilio to point to our brain"""
    print(f"🔄 Updating Twilio webhooks to: {brain_url}")

    async with httpx.AsyncClient() as client:
        auth = (TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)

        # Get all phone numbers
        response = await client.get(
            f"https://api.twilio.com/2010-04-01/Accounts/{TWILIO_ACCOUNT_SID}/IncomingPhoneNumbers.json",
            auth=auth
        )

        numbers = response.json()['incoming_phone_numbers']

        for number_data in numbers:
            if number_data['phone_number'] in ["+13239685736", "+17027109167", "+17027186386", "+17027104257", "+17027124212", "+17027104174", "+18669658975"]:
                print(f"  Updating {number_data['phone_number']}...")

                # Update to point to Retell
                update_response = await client.post(
                    f"https://api.twilio.com/2010-04-01/Accounts/{TWILIO_ACCOUNT_SID}/IncomingPhoneNumbers/{number_data['sid']}.json",
                    auth=auth,
                    data={
                        "VoiceUrl": f"https://api.retellai.com/twilio/voice/{RETELL_API_KEY}",
                        "VoiceMethod": "POST",
                        "StatusCallback": f"{brain_url}/webhooks/twilio/status",
                        "StatusCallbackMethod": "POST"
                    }
                )

                if update_response.status_code == 200:
                    print(f"  ✅ {number_data['phone_number']} updated")

async def main():
    """Full migration process"""
    print("🚀 AI JESUS BRO NUMBER MIGRATION")
    print("="*50)

    # Step 1: Check current Vapi status
    vapi_numbers = await check_vapi_numbers()

    print("\n📋 Migration Plan:")
    print("1. Release +13239685736 from Vapi")
    print("2. Configure Retell SIP trunk")
    print("3. Import all numbers to Retell")
    print("4. Update Twilio webhooks")

    input("\nPress Enter to proceed (or Ctrl+C to cancel)...")

    # Step 2: Release from Vapi
    if "+13239685736" in vapi_numbers:
        await release_from_vapi("+13239685736")

    # Step 3: Configure Retell
    await configure_retell_sip()

    # Step 4: Import numbers
    await import_numbers_to_retell()

    # Step 5: Update webhooks (will do after brain is running)
    # brain_url = "http://localhost:8081"  # Local for now
    # await update_twilio_webhooks(brain_url)

    print("\n✅ MIGRATION COMPLETE!")
    print("Numbers are now under AI Jesus Bro control")
    print("\nNext step: Start the brain and update webhooks to production URL")

if __name__ == "__main__":
    asyncio.run(main())